//
//  TYGOtherViewController.h
//  SuperDemo
//
//  Created by tanyugang on 15/6/10.
//  Copyright (c) 2015年 TYG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TYGOtherViewController : UIViewController

- (IBAction)buttonClick:(UIButton *)sender;

@end
