//
//  TYGPopAnimationDemo.h
//  SuperDemo
//
//  Created by 谈宇刚 on 16/4/5.
//  Copyright © 2016年 TYG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TYGPopAnimationDemo : UITableViewController

@end
