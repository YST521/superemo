//
//  PopBasicViewController.h
//  SuperDemo
//
//  Created by tanyugang on 15/5/19.
//  Copyright (c) 2015年 TYG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PopBasicViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIView *basicView;
@property (weak, nonatomic) IBOutlet UILabel *basicLabel;

@end
