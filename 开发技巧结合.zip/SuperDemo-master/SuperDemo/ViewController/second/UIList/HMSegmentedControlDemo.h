//
//  HMSegmentedControlDemo.h
//  SuperDemo
//
//  Created by 谈宇刚 on 15/9/1.
//  Copyright (c) 2015年 TYG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HMSegmentedControl.h"

@interface HMSegmentedControlDemo : UIViewController<UIScrollViewDelegate>

@end
