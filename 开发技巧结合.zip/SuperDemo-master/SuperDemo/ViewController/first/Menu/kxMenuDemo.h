//
//  kxMenuDemo.h
//  SuperDemo
//
//  Created by tanyugang on 15/4/20.
//  Copyright (c) 2015年 TYG. All rights reserved.
//
//  垂直的弹出式菜单

#import <UIKit/UIKit.h>

@interface kxMenuDemo : UIViewController

@end
