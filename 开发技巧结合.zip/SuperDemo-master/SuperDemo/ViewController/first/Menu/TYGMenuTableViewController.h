//
//  TYGMenuTableViewController.h
//  SuperDemo
//
//  Created by tanyugang on 15/6/5.
//  Copyright (c) 2015年 TYG. All rights reserved.
//
//  菜单、目录集合

#import <UIKit/UIKit.h>

@interface TYGMenuTableViewController : UITableViewController

@end
