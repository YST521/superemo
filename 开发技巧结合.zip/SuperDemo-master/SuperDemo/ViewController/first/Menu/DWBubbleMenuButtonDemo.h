//
//  DWBubbleMenuButtonDemo.h
//  SuperDemo
//
//  Created by tanyugang on 15/6/5.
//  Copyright (c) 2015年 TYG. All rights reserved.
//
//  一个带有动画的菜单按钮类。允许朝上下左右四个方向展开和收起菜单，菜单的数量是可变的

#import <UIKit/UIKit.h>

@interface DWBubbleMenuButtonDemo : UIViewController

@end
