//
//  IGLDemoViewController.h
//  IGLDropDownMenuDemo
//
//  Created by Galvin Li on 8/30/14.
//  Copyright (c) 2014 Galvin Li. All rights reserved.
//
//  有多种自定义动画效果的下拉菜单

#import <UIKit/UIKit.h>

@interface IGLDemoViewController : UIViewController

@end
