//
//  QBPopupMenuDemo.h
//  SuperDemo
//
//  Created by tanyugang on 15/6/5.
//  Copyright (c) 2015年 TYG. All rights reserved.
//
//  横向的弹出式菜单
#import <UIKit/UIKit.h>

@interface QBPopupMenuDemo : UIViewController

@end
