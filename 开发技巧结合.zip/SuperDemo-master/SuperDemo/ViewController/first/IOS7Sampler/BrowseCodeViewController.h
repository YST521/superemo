//
//  BrowseCodeViewController.h
//  iOS7Sampler
//
//  Created by shuichi on 2/10/14.
//  Copyright (c) 2014 Shuichi Tsutsumi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BrowseCodeViewController : UIViewController

@property (nonatomic, strong) NSString *urlString;

@end
