//
//  SloMoVideoRecordViewController.h
//  https://github.com/shu223/SlowMotionVideoRecorder
//
//  Created by shuichi on 1/5/14.
//  Copyright (c) 2014 Shuichi Tsutsumi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SloMoVideoRecordViewController : UIViewController

@end
