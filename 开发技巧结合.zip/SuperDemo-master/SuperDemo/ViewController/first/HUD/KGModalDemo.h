//
//  KGModalDemo.h
//  SuperDemo
//
//  Created by 谈宇刚 on 15/8/20.
//  Copyright (c) 2015年 TYG. All rights reserved.
//
//  一个易用的模态弹出窗口控件

#import <UIKit/UIKit.h>

@interface KGModalDemo : UIViewController

@end
