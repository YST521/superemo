//
//  ViewController.h
//  areapicker
//
//  Created by tanyugang on 15/4/20.
//  Copyright (c) 2015年 TYG. All rights reserved.
//
//  地区选取器-TYGAreaPickerViewDemo

#import <UIKit/UIKit.h>

@interface TYGAreaPickerViewDemo : UIViewController

@end
