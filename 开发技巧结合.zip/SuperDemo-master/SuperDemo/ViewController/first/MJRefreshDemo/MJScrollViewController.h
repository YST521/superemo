//
//  MJScrollViewController.h
//  MJRefreshExample
//
//  Created by 谈宇刚 on 14-10-28.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MJScrollViewController : UIViewController

@property (nonatomic, strong)UIScrollView *scrollView;

@end
