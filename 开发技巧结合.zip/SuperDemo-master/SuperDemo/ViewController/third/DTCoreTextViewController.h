//
//  DTCoreTextViewController.h
//  SuperDemo
//
//  Created by tanyugang on 15/7/1.
//  Copyright © 2015年 TYG. All rights reserved.
//  DTCoreText，一个功能十分强大的文字效果代码类库,在UITextView上实现十分丰富的文字效果，包括文字大小、颜色、字体、下划线，链接，给文字加上图片、视频，文字任意间距等等。实现类似于CSS网页的文字效果

#import <UIKit/UIKit.h>

@interface DTCoreTextViewController : UIViewController

@end
