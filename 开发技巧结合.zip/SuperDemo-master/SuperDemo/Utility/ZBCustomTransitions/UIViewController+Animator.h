@interface UIViewController (Animator)
@property (retain) id animator;
@end
