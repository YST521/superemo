//
//  TYG_allHeadFiles.h
//  2013002-­2
//
//  Created by  tanyg on 13-8-27.
//  Copyright (c) 2013年 2013002-­2. All rights reserved.
//
/**
 *  描述：各种自定义类的头文件
 *  作者：谈宇刚
 *  日期：2013年8月27日
 *  版本：1.0
 */

#import <Foundation/Foundation.h>
#import "Utility.h"
#import "CommonHeader.h"
#import "W_R_Plist.h"
#import "TYG_UIItems.h"
#import "TYGConfig.h"
#import "TYGValid.h"

#import "SVProgressHUD.h"
#import "TSMessage.h"
#import <Masonry.h>

@protocol TYG_allHeadFiles <NSObject>

@end