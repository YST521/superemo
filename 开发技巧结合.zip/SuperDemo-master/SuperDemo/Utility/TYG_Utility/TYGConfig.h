//
//  TYGConfig.h
//  AutomobileMarket
//
//  Created by tanyugang on 15/4/16.
//  Copyright (c) 2015年 YDAPP. All rights reserved.
//

/**
 *  配置各种参数
 */

#ifndef AutomobileMarket_TYGConfig_h
#define AutomobileMarket_TYGConfig_h



#endif
